
<!DOCTYPE html>
<html>
<head>
</head>
<body>

<?php
$q = $_GET['q'];

$con = mysqli_connect('localhost','root','root','StudentDB');

if($con)
//echo "<h1>connected:" . $q . "</h1>";
//else
//echo "<h1>Not connected</h1>";
if (!$con) {
    die('Could not connect: ' . mysqli_error($con));
}

mysqli_select_db($con,"StudentDB");
$sql="SELECT * FROM users WHERE uname = '".$q."'";
$result = mysqli_query($con,$sql);
$count=mysqli_num_rows($result);
if($count) {
       	echo "Username " . $q . " Already Exists..";

}




mysqli_close($con);
?>
</body>
</html> 
